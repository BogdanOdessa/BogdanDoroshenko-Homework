using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public interface ISpeedChange
{

    void SpeedIncrease();
    void SpeedDecrease();
    void SpeedNormal();

  }
