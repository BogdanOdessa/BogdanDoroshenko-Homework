using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IBonus
{
    void InitiateBonusTimer();

    void GetBonus();
}
