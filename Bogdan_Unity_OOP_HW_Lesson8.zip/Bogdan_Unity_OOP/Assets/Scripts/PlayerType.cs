namespace Game
{
    public enum PlayerType
    {
        None = 0,
        Ball = 1,
        Cube = 2
    }

}

