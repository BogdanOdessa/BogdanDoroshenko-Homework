﻿using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("com.unity.cinemachine.editor")]