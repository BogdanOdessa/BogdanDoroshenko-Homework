# Hard Look At

This Virtual Camera __Aim__ algorithm rotates the Virtual Camera to keep the __Look At__ target in the center of the camera frame.

